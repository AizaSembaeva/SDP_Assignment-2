package Сharacter;

public class Swordsman implements ICharacter {
    @Override
    public void attack(){
        System.out.println("I'm attacking");
    }

    @Override
    public void defense(){
        System.out.println("I'm defending with sword");
    }

    @Override
    public void move(){
        System.out.println("I'm moving");
    }
}
