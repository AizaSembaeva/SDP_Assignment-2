package Сharacter;

public class Archer implements ICharacter {
    @Override
    public void attack(){
        System.out.println("I'm shooting");
    }

    @Override
    public void defense(){
        System.out.println("I'm defending with bow");
    }

    @Override
    public void move(){
        System.out.println("I'm moving");
    }
}
