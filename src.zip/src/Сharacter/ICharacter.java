package Сharacter;

public interface ICharacter {
    void attack();
    void defense();
    void move();
}
