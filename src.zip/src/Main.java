import Factory_Method.ArcherFactory;
import Factory_Method.CharacterFactory;

public class Main {
    public static void main(String[] args) {
            CharacterFactory characterFactory = new ArcherFactory();
            Character Archer = characterFactory.createCharacter();
        }
    }
}