package Abstract_Factory;

import Race.Orc;
import Race.IRace;
import Сharacter.ICharacter;
import Сharacter.Archer;

public class OrcArcher implements WarriorFactory {
    @Override
    public IRace createRace(){
        return new Orc();
    }

    @Override
    public ICharacter createCharacter(){
        return new Archer();
    }
}
