package Abstract_Factory;

import Race.Elf;
import Race.IRace;
import Сharacter.ICharacter;
import Сharacter.Archer;

public class ElfArcher implements WarriorFactory {
    @Override
    public IRace createRace(){
        return new Elf();
    }

    @Override
    public ICharacter createCharacter(){
        return new Archer();
    }
}