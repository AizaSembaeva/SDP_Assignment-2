package Race;

public interface IRace {
    void useRacialAbility();
    void battleCry();;
}
