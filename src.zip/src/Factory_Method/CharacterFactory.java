package Factory_Method;

import Сharacter.ICharacter;

public abstract class CharacterFactory {
    public abstract ICharacter createCharacter();
}
