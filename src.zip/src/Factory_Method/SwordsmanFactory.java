package Factory_Method;

import Сharacter.ICharacter;
import Сharacter.Swordsman;

public class SwordsmanFactory extends CharacterFactory {
    @Override
    public ICharacter createCharacter() {
        return new Swordsman();
    }

}
