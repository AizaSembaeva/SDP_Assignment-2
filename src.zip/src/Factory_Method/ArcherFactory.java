package Factory_Method;

import Сharacter.Archer;
import Сharacter.ICharacter;

public class ArcherFactory extends CharacterFactory {
    @Override
    public ICharacter createCharacter() {
        return new Archer();
    }
}
