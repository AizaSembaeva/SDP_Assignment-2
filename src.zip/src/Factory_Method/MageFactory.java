package Factory_Method;

import Сharacter.ICharacter;
import Сharacter.Mage;

public class MageFactory extends CharacterFactory {
    @Override
    public ICharacter createCharacter() {
        return new Mage();
    }
}
